<?php

// Connect to the database
$db = new PDO('mysql:host=localhost;courtcase', 'root', '');

// Get the list of cases
$sql = "SELECT * FROM courtcase";


// Initialize the points array
$points = [];

// Loop through the cases
foreach ($result as $row) {
  // Get the number of serious IPCs
  $numSeriousIpcs = count(explode(',', $row['Severe_crime_under_IPC']));

  // Get the time difference between the filing date and the last hearing date
  $timeDiff = strtotime($row['Time_of_filing_chartSheet']) - strtotime($row['Last_hearing_date']);

  // Calculate the points for the case
  $points[$row['id']] = $numSeriousIpcs * 10 + ($timeDiff / 15) * 2 + ($timeDiff / 20) * 2;
}

// Sort the cases by points in descending order
arsort($points);

// Get the list of cases in priority order
$priorityCases = array_keys($points);

// Print the list of priority cases
echo '<ul>';
foreach ($priorityCases as $caseId) {
  echo '<li>' . $caseId . '</li>';
}
echo '</ul>';

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Case Update</title>
</head>
<style>
    /* Add your CSS styles here */
    body {
        background-color: lightgray;
    }
    
    #header-div {
        background-color: lightgray;
        margin-bottom: 10px;
        padding: auto;
    }
    
    #main-div {
        width: 100%;
        background-color: white;
    }
    
    #button-div {
        width: 11;
        min-height: 700px;
        background-color: white;
        float: left;
        padding-left: 10px;
        padding-right: 10px;
        padding-top: 10px;
    }
    
    #bodyarea-div {
        width: 78%;
        min-height: 700px;
        background-color: lightgray;
        float: left;
        box-sizing: content-box;
        padding-top: 10px;
        padding-left: 10px;
        font-size: xx-large;
        display: inline;
        overflow: scroll;
    }
    
    #sidebar-div {
        width: 11%;
        min-height: 700px;
        background-color: white;
        float: right;
        padding-left: 7.5px;
        padding-top: 10px;
        color: gray;
    }
    
    .center {
        text-align: center;
        color: blue;
        padding-bottom: 20px;
    }
    
    .f {
        padding-top: 20;
        padding-bottom: 20px;
        font-size-adjust: inherit;
    }
    
    #scroll-container {
        border: 3px solid black;
        border-radius: 5px;
        height: 100px;
        overflow: hidden;
    }
    
    #scroll-text {
        height: 100%;
        text-align: center;
        /* animation properties */
        -moz-transform: translateY(100%);
        -webkit-transform: translateY(100%);
        transform: translateY(100%);
        -moz-animation: my-animation 5s linear infinite;
        -webkit-animation: my-animation 5s linear infinite;
        animation: my-animation 5s linear infinite;
    }
    /* for Firefox */
    
    @-moz-keyframes my-animation {
        from {
            -moz-transform: translateY(100%);
        }
        to {
            -moz-transform: translateY(-100%);
        }
    }
    /* for Chrome */
    
    @-webkit-keyframes my-animation {
        from {
            -webkit-transform: translateY(100%);
        }
        to {
            -webkit-transform: translateY(-100%);
        }
    }
    
    @keyframes my-animation {
        from {
            -moz-transform: translateY(100%);
            -webkit-transform: translateY(100%);
            transform: translateY(100%);
        }
        to {
            -moz-transform: translateY(-100%);
            -webkit-transform: translateY(-100%);
            transform: translateY(-100%);
        }
    }
    
    #scroll-container {
        height: 550px;
    }

</style>

<body>

    <div id="main-div">
        <div id="button-div">
            <!-- Add your buttons here -->
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px;border-color:deepskyblue;">HOME</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ; font-size: 20px;border-radius: 12px; border-color: deepskyblue;">NJDG</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px; border-color: deepskyblue;">CIS</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px; border-color: deepskyblue;">Supreme Court</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px; border-color: deepskyblue;">High court</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px; border-color: deepskyblue;">Distric Court</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px; border-color: deepskyblue;">View List</button> <br> <br>
            <button style="background-color: deepskyblue;color: white;width:120px; height:70px ;font-size: 20px;border-radius: 12px; border-color: deepskyblue;">Login</button> <br> <br>
        </div>
        </div>
        <div id="bodyarea-div">
            <div class="center">
                <button style="background-color: deepskyblue;color: white;width:200px; height:50px ;text-align: center;font-size: 20px;border-color: deepskyblue">Case Update</button>
            </div>

            <form name="caseUpdate" action="" method="post">
                <table border="0">
                    <tbody>
                        <tr>
                            <td><label for="caseNo">Case No</label></td>
                            <td><input id="caseNo" maxlength="50" name="caseNo" type="text" /></td>
                        </tr>
                        <tr>
                            <td><label for="severity">Severity of the Crime and Section Involved</label></td>
                            <td><input id="severity" maxlength="50" name="severity" type="text" /></td>
                        </tr>
                        <tr>
                            <td><label for="chargeSheetTime">Time of Filing of Chargesheet</label></td>
                            <td><input id="chargeSheetTime" maxlength="50" name="chargeSheetTime" type="text" /></td>
                        </tr>
                        <tr>
                            <td><label for="hearingDate">Last Hearing Date</label></td>
                            <td><input id="hearingDate" maxlength="50" name="hearingDate" type="text" /></td>
                        </tr>
                    </tbody>
                </table>
                <div>
                    <input type="submit" name="submit" value="Submit">
                </div>
            </form>

            <div>
                <h2>Case Updates</h2>
                <?php if (!empty($data)) : ?>
                    <table border="1">
                        <thead>
                            <tr>
                                <th>Case No</th>
                                <th>Severity</th>
                                <th>Chargesheet Time</th>
                                <th>Last Hearing Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data as $row) : ?>
                                <tr>
                                    <td><?php echo $row['caseNo']; ?></td>
                                    <td><?php echo $row['severity']; ?></td>
                                    <td><?php echo $row['chargeSheetTime']; ?></td>
                                    <td><?php echo $row['hearingDate']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else : ?>
                    <p>No case updates available.</p>
                <?php endif; ?>
            </div>
        </div>
        <div id="sidebar-div">
            <!-- Add your sidebar content here -->
        </div>
    </div>

</body>

</html>