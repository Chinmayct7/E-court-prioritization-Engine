-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 09, 2023 at 08:38 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `courtcase`
--

-- --------------------------------------------------------

--
-- Table structure for table `court1_cases`
--

CREATE TABLE `court1_cases` (
  `Sr no` int(11) NOT NULL,
  `Case_no` int(20) NOT NULL,
  `Severe_crime_under_IPC` varchar(20) NOT NULL,
  `Other_IPC` varchar(20) NOT NULL,
  `Time_of_filing_chartSheet` date NOT NULL,
  `Last_hearing_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `court1_cases`
--

INSERT INTO `court1_cases` (`Sr no`, `Case_no`, `Severe_crime_under_IPC`, `Other_IPC`, `Time_of_filing_chartSheet`, `Last_hearing_date`) VALUES
(0, 111, '302', '463', '2014-01-03', '2015-01-03'),
(0, 222, '304', '415, 420', '2016-01-03', '2017-01-03'),
(0, 333, '121', '503, 506', '2018-01-03', '2019-01-03'),
(0, 444, '120', '66A, 382', '2019-07-03', '2019-08-03'),
(0, 555, '121A', '480 , 351', '2018-07-03', '2019-09-03'),
(0, 666, '307', '356', '2019-09-09', '2019-10-03'),
(0, 777, '359', '280', '2020-01-03', '2020-08-03'),
(0, 888, '392 , 121A', '380', '2020-09-03', '2020-10-03'),
(0, 999, '376', '451', '2021-01-03', '2022-01-03'),
(0, 1010, '120', '459', '2022-07-03', '2023-01-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `court1_cases`
--
ALTER TABLE `court1_cases`
  ADD PRIMARY KEY (`Case_no`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
